﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лабораторна_робота_6_Подставіна_Ганна_БІП_1_25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Введiть перше число: ");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введiть друге число: ");
                int y = Convert.ToInt32(Console.ReadLine());
                int z = x / y;
                Console.WriteLine($"Результат дiлення: {z}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Помилка! Дiлення на нуль неможливе!" + ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Помилка! Потрiбно вводити числа!" + ex.Message);
            }
        }
    }
}
